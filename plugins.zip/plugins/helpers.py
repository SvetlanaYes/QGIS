from qgis.core import QgsApplication
import os
import json
from PyQt5.QtWidgets import QMessageBox

plugin_path = QgsApplication.qgisSettingsDirPath()


def get_dataset_path():
    return os.path.join(plugin_path, "python/plugins/database.json")


def get_server_path():
    return os.path.join(plugin_path, "python/plugins/server.json")


def get_config_path():
    return os.path.join(plugin_path, "python/plugins/config.json")


def get_db_queries_path():
    return os.path.join(plugin_path, "python/plugins/DB_QUERIES.json")


def read_json(filename):
    with open(filename, 'r') as file:
        data = json.load(file)
    return data


def write_to_json(filename, data):
    with open(filename, 'w') as json_file:
        json.dump(data, json_file)


def show_warning_message(text):
    msg = QMessageBox()
    msg.setIcon(QMessageBox.Warning)
    msg.setText("Warning")
    msg.setInformativeText(str(text))
    msg.setWindowTitle("Warning")
    msg.exec_()
